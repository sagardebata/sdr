TW.Runtime.Widgets.customimageinputL= function () {
	var _uuid;
	var customcameracontrol;
	var valueElem;
	var ImageFile;
	var widgetRef = this;
	this.renderHtml = function () {
		// return any HTML you want rendered for your widget
		// If you want it to change depending on properties that the user
		// has set, you can use this.getProperty(propertyName). In
		// this example, we'll just return static HTML
		_uuid = TW.uniqueId();
		customcameracontrol = getControl();
		var srcImage = this.getProperty('SourceURL');
        

        //  imageScale = thisWidget.getProperty('Scaling');

		if( srcImage === undefined ) {
			srcImage = '';
		} else {
			srcImage = TW.convertImageLink(srcImage);
		}
		
		return 	'<div class="widget-content widget-customimageinputL width">' +
		
		'<label  for="'+ customcameracontrol + '" class="custom-file-uploadimg">'+
		'<img src="' + srcImage + '" alt="' + 
		(this.getProperty('customimageinputL Property') !== undefined ? this.getProperty('customimageinputL Property') : '') +
		'" width="auto" height="auto"  />'+
		//'/>'+
        '</label>'+
        
                  
		'<input style="display: none" type="file"  accept="image/*" size="35" capture="camera" id="'+ 
		customcameracontrol+
		'" />'+
		
					
				'</div>';
	};

	this.afterRender = function () {
		// NOTE: this.jqElement is the jquery reference to your html dom element
		// 		 that was returned in renderHtml()

		// get a reference to the value element
		valueElem = this.jqElement.find('.customimageinputL-property');
		// update that DOM element based on the property value that the user set
		// in the mashup builder
		valueElem.text(this.getProperty('customimageinputL Property'));
		
		ImageFile = this.jqElement.find('#'+customcameracontrol);
		
		ImageFile.change( function(e){
			 TW.log.info('in change method');
			var filesSelected = ImageFile[0].files;
		    if (filesSelected.length > 0)
		    {
		        var fileToLoad = filesSelected[0];

		        var fileReader = new FileReader();

		        fileReader.onload = function(fileLoadedEvent) 
		        {
		            var snap = fileLoadedEvent.target.result;
		            TW.log.info('param set' +snap);
		            widgetRef.setProperty('ImageURL',snap );
		            TW.log.info('param set done');
		            widgetRef.jqElement.triggerHandler('ImageURLChanged');
		        };

		        fileReader.readAsDataURL(fileToLoad);
		    }
			 
		});
		
		
	};

	// this is called on your widget anytime bound data changes
	this.updateProperty = function (updatePropertyInfo) {
		// TargetProperty tells you which of your bound properties changed
		if (updatePropertyInfo.TargetProperty === 'customimageinputL Property') {
			valueElem.text(updatePropertyInfo.SinglePropertyValue);
			this.setProperty('customimageinputL Property', updatePropertyInfo.SinglePropertyValue);
		}
	};
	
	 var getControl = function () {
	        return 'customcameracontrol-' + _uuid;
	    };
};