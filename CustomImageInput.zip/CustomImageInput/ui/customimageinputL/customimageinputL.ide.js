TW.IDE.Widgets.customimageinputL = function () {

	this.widgetIconUrl = function() {
		return  "'../Common/extensions/customimageinputL/ui/customimageinputL/default_widget_icon.ide.png'";
	};

	this.widgetProperties = function () {
		return {
			'name': 'customimageinputL',
			'description': '',
			'category': ['Common'],
			'properties': {
				'customimageinputL Property': {
					'baseType': 'STRING',
					'defaultValue': '',
					'isBindingTarget': true,
					'isBindingSource': true,
				},
				
				'ImageURL':{
					'isBindingSource': true,
                    'defaultValue': '',
                    'baseType': 'STRING'
				},
				
				'SourceURL':{
					 'defaultValue': '',
	                    'isBindingTarget': true,
	                    'baseType': 'IMAGELINK',
				}
			}
		}
	};
	
	  this.widgetEvents = function () {
	        return {
	            'ImageURLChanged': { 'warnIfNotBound': false }
	          
	        };
	    };


	this.afterSetProperty = function (name, value) {
		var thisWidget = this;
		var refreshHtml = false;
		switch (name) {
			case 'Style':
			case 'customimageinputL Property':
				thisWidget.jqElement.find('.customimageinputL-property').text(value);
			case 'Alignment':
				refreshHtml = true;
				break;
			default:
				break;
		}
		return refreshHtml;
	};

	this.renderHtml = function () {
		
		  var srcImage = this.getProperty('SourceURL');
	        

	        //  imageScale = thisWidget.getProperty('Scaling');

	          if( srcImage === undefined ) {
	              srcImage = '';
	          } else {
	              srcImage = TW.convertImageLink(srcImage);
	          }
			
		// return any HTML you want rendered for your widget
		// If you want it to change depending on properties that the user
		// has set, you can use this.getProperty(propertyName).
		return 	'<div class="widget-content widget-customimageinputL">' +
		'<img src="' + srcImage + '" alt="' + 
		(this.getProperty('customimageinputL Property') !== undefined ? this.getProperty('customimageinputL Property') : '') +
		'" width="auto" height="auto""  />'+	
			'</div>';
	};

	this.afterRender = function () {
		// NOTE: this.jqElement is the jquery reference to your html dom element
		// 		 that was returned in renderHtml()

		// get a reference to the value element
		valueElem = this.jqElement.find('.customimageinputL-property');
		// update that DOM element based on the property value that the user set
		// in the mashup builder
		valueElem.text(this.getProperty('customimageinputL Property'));
	};

};